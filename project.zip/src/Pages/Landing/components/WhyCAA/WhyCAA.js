const WhyCAA = () => {
    return ( 
        <div></div>
     );
}
 
export default WhyCAA;