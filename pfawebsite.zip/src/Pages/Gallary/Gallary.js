import React, {useEffect} from "react";
import Layout from "../../Components/Layout/Layout";
import Gallery from "react-grid-gallery";
import { scrollToTop } from "../../Utils/Common";
import s1 from './s1.jpeg'
import s2 from './s2.jpeg'
import s3 from './s3.jpeg'
import s4 from './s4.jpeg'
import s5 from './s5.jpeg'
import s6 from './s6.jpeg'
import s7 from './s7.jpeg'

const Gallary = () => {
  useEffect(() => {
    scrollToTop();
  }, []);
  const IMAGES = [
    {
      src: '{{s1}}',
      thumbnail:
        "s1.jpeg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
      isSelected: false,
      caption: "After Rain (Jeshu John - designerspics.com)",
    },
    {
      src: "https://c2.staticflickr.com/9/8356/28897120681_3b2c0f43e0_b.jpg",
      thumbnail:
        "https://c2.staticflickr.com/9/8356/28897120681_3b2c0f43e0_n.jpg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
      tags: [
        { value: "Ocean", title: "Ocean" },
        { value: "People", title: "People" },
      ],
      caption: "Boats (Jeshu John - designerspics.com)",
    },

    {
      src: "https://c4.staticflickr.com/9/8887/28897124891_98c4fdd82b_b.jpg",
      thumbnail:
        "https://c4.staticflickr.com/9/8887/28897124891_98c4fdd82b_n.jpg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
    },
    {
      src: "https://c2.staticflickr.com/9/8817/28973449265_07e3aa5d2e_b.jpg",
      thumbnail:
        "https://c2.staticflickr.com/9/8817/28973449265_07e3aa5d2e_n.jpg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
      isSelected: false,
      caption: "After Rain (Jeshu John - designerspics.com)",
    },
    {
      src: "https://c2.staticflickr.com/9/8356/28897120681_3b2c0f43e0_b.jpg",
      thumbnail:
        "https://c2.staticflickr.com/9/8356/28897120681_3b2c0f43e0_n.jpg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
      tags: [
        { value: "Ocean", title: "Ocean" },
        { value: "People", title: "People" },
      ],
      caption: "Boats (Jeshu John - designerspics.com)",
    },

    {
      src: "https://c4.staticflickr.com/9/8887/28897124891_98c4fdd82b_b.jpg",
      thumbnail:
        "https://c4.staticflickr.com/9/8887/28897124891_98c4fdd82b_n.jpg",
      thumbnailWidth: 320,
      thumbnailHeight: 212,
    },
  ];
  return (
    <div>
      <Layout title="Galary Page">
        <div className="container pb-5">
          <div className="row pt-5 mb-3 text-center">
            <div className="col">
              <h1>GALLARY</h1>
            </div>
          </div>
          <div
            className="row mb-4"
            style={{
              display: "block",
              minHeight: "1px",
              width: "100%",
              border: "1px solid #ddd",
              overflow: "auto",
            }}
          >
            <Gallery
              images={IMAGES}
              backdropClosesModal={true}
              margin={10}
              enableLightbox={true}
              rowHeight={240}
              columnWidth={320}
            />
          </div>
        </div>
      </Layout>
    </div>
  );
};

export default Gallary;
